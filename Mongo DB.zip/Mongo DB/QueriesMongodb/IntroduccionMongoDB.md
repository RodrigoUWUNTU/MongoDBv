
# Introduccion a Mongo DB 

## Ejemplo de Sintaxis de JSO 

`
{
    nombre : "Luis" ,
    Edad: 45 ,
    tel: 777,
}
`

# Ejemplo se Sintaxis más complejos

`
{ 
    "nombre" : Luisa,
    Edad: 42 ,
    tel: 777,
    aficiones : [
        "Ejercicio",
        "Programar",
        "Correr"
    ],
    Skill: {
       "Programacion": "20%",
       "Diseño web": "45%" 
    }
}
`